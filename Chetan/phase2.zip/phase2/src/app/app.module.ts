import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { TrainerLoginComponent } from './trainer-login/trainer-login.component';
import { TrainerSignupComponent } from './trainer-signup/trainer-signup.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { UserComponent } from './user/user.component';
import { TrainerComponent } from './trainer/trainer.component';
import { AdminComponent } from './admin/admin.component';
import { BlockUserComponent } from './block-user/block-user.component';
import { BlockTrainerComponent } from './block-trainer/block-trainer.component';
import { EditTechnologiesComponent } from './edit-technologies/edit-technologies.component';
import { EditSkillsComponent } from './edit-skills/edit-skills.component';
import { UserCompletedTrainingsComponent } from './user-completed-trainings/user-completed-trainings.component';
import { UserCurrentTrainingsComponent } from './user-current-trainings/user-current-trainings.component';
import { SearchComponent } from './search/search.component';
import { TrainerCompletedTrainingsComponent } from './trainer-completed-trainings/trainer-completed-trainings.component';
import { TrainerCurrentTrainingsComponent } from './trainer-current-trainings/trainer-current-trainings.component';
import { NotificationsComponent } from './notifications/notifications.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UserLoginComponent,
    AdminLoginComponent,
    TrainerLoginComponent,
    TrainerSignupComponent,
    UserSignupComponent,
    UserComponent,
    TrainerComponent,
    AdminComponent,
    BlockUserComponent,
    BlockTrainerComponent,
    EditTechnologiesComponent,
    EditSkillsComponent,
    UserCompletedTrainingsComponent,
    UserCurrentTrainingsComponent,
    SearchComponent,
    TrainerCompletedTrainingsComponent,
    TrainerCurrentTrainingsComponent,
    NotificationsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
