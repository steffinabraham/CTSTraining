import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, Validators } from '@angular/forms';
import {Router} from "@angular/router";

@Component({
  selector: 'app-user-signup',
  templateUrl: './user-signup.component.html',
  styleUrls: ['./user-signup.component.css']
})
export class UserSignupComponent implements OnInit {

  userSignUp : FormGroup;

  constructor(private fb:FormBuilder,private router: Router) {

    this.userSignUp = this.fb.group({
      name : ['',Validators.required],
      email :['',Validators.required],
      age : ['', [Validators.required, Validators.min(2), Validators.max(100)]],
      password : ['', [Validators.required, Validators.minLength(6)]],
      checkPassword : ['',[Validators.required, Validators.minLength(6)]]
    })


   }

   onSubmit(){
     
    this.router.navigate(['/user-login']);
   }


  ngOnInit() {
  }

}
