import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainer-completed-trainings',
  templateUrl: './trainer-completed-trainings.component.html',
  styleUrls: ['./trainer-completed-trainings.component.css']
})
export class TrainerCompletedTrainingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
