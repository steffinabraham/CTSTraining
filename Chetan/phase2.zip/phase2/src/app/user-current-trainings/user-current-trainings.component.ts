import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-current-trainings',
  templateUrl: './user-current-trainings.component.html',
  styleUrls: ['./user-current-trainings.component.css']
})
export class UserCurrentTrainingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
