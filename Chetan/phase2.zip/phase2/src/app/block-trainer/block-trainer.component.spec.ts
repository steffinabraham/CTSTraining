import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockTrainerComponent } from './block-trainer.component';

describe('BlockTrainerComponent', () => {
  let component: BlockTrainerComponent;
  let fixture: ComponentFixture<BlockTrainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlockTrainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlockTrainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
