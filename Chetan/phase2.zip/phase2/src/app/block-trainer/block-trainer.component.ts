import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup } from '@angular/forms';
import {Router} from "@angular/router";

@Component({
  selector: 'app-block-trainer',
  templateUrl: './block-trainer.component.html',
  styleUrls: ['./block-trainer.component.css']
})
export class BlockTrainerComponent implements OnInit {

  blockTrainer:FormGroup;

  constructor(private router:Router) { 
      this.blockTrainer = new FormGroup({
        userName: new FormControl('')
      
      });
  
  }
  onSubmit(){
    this.router.navigate(['/admin']);
  }

  ngOnInit() {
  }

}
