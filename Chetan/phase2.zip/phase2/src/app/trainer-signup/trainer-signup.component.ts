import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, Validators } from '@angular/forms';
import {Router} from "@angular/router";

@Component({
  selector: 'app-trainer-signup',
  templateUrl: './trainer-signup.component.html',
  styleUrls: ['./trainer-signup.component.css']
})
export class TrainerSignupComponent implements OnInit {

  trainerSignUp : FormGroup;

  constructor(private fb:FormBuilder,private router: Router) {

    this.trainerSignUp = this.fb.group({
      name : ['',Validators.required],
      email :['',Validators.required],
      age : ['', [Validators.required, Validators.min(2), Validators.max(100)]],
      password : ['', [Validators.required, Validators.minLength(6)]],
      checkPassword : ['',[Validators.required, Validators.minLength(6)]]
    })


   }

   onSubmit(){
     
    this.router.navigate(['/trainer-login']);
   }

  ngOnInit() {
  }

}
