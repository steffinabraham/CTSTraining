import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms';
import {Router} from '@angular/router';

@Component({
  selector: 'app-trainer-login',
  templateUrl: './trainer-login.component.html',
  styleUrls: ['./trainer-login.component.css']
})
export class TrainerLoginComponent implements OnInit {

  trainerLogin : FormGroup;
  constructor(private router :Router) {

    this.trainerLogin = new FormGroup({
      userName: new FormControl(''),
      password: new FormControl(''),
    });
  }

  onSubmit(){
    if((this.trainerLogin.get("userName").value == "trainer@mod.com")&&(this.trainerLogin.get("password").value == "1234")){

      this.router.navigate(['/trainer']);
     }else{
      alert("Wrong Credentials");
     }
  }

  ngOnInit() {
  }

}
