import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-technologies',
  templateUrl: './edit-technologies.component.html',
  styleUrls: ['./edit-technologies.component.css']
})
export class EditTechnologiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
