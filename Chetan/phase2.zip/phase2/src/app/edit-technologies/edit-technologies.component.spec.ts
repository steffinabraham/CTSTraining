import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditTechnologiesComponent } from './edit-technologies.component';

describe('EditTechnologiesComponent', () => {
  let component: EditTechnologiesComponent;
  let fixture: ComponentFixture<EditTechnologiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditTechnologiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditTechnologiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
