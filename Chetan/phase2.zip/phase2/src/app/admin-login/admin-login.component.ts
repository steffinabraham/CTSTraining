import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {Router} from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  adminLogin:FormGroup;
  constructor(private router:Router) { 
    this.adminLogin=new FormGroup({
      username: new FormControl(''),
      password:new FormControl('')
    });

  }


  onSubmit(){
    if((this.adminLogin.get("username").value=="admin@mod.com") && (this.adminLogin.get("password").value=="1234")){
      this.router.navigate(['/admin']);
    } else{
      alert("Wrong Credentials");
    }
  }
  ngOnInit() {
  }

}
