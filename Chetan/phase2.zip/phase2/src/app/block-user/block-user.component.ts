import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup } from '@angular/forms';
import {Router} from "@angular/router";

@Component({
  selector: 'app-block-user',
  templateUrl: './block-user.component.html',
  styleUrls: ['./block-user.component.css']
})
export class BlockUserComponent implements OnInit {

  blockUser : FormGroup;

  constructor(private router : Router) { 
    this.blockUser = new FormGroup({
      userName: new FormControl('')
    
    });

  }
  onSubmit(){
    this.router.navigate(['/admin']);
  }


  ngOnInit() {
  }

}
