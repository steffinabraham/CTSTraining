import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainer-current-trainings',
  templateUrl: './trainer-current-trainings.component.html',
  styleUrls: ['./trainer-current-trainings.component.css']
})
export class TrainerCurrentTrainingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
