import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup } from '@angular/forms';
import {Router} from "@angular/router";


@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  userLogin : FormGroup;
  
  constructor(private router: Router) { 

    this.userLogin = new FormGroup({
      userName: new FormControl(''),
      password: new FormControl(''),
    });

  }

  onSubmit(){
   if((this.userLogin.get("userName").value == "user@mod.com")&&(this.userLogin.get("password").value == "1234")){

    this.router.navigate(['/user']);
   }else{
    alert("Wrong Credentials");
   }

    
  }

  

  ngOnInit() {
  }

}
