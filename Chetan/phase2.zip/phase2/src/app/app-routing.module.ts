import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent} from './home/home.component';
import {UserLoginComponent} from './user-login/user-login.component';
import {TrainerLoginComponent} from './trainer-login/trainer-login.component';
import {AdminLoginComponent} from './admin-login/admin-login.component';
import {UserSignupComponent} from './user-signup/user-signup.component';
import {TrainerSignupComponent} from './trainer-signup/trainer-signup.component';
import {UserComponent} from './user/user.component';
import {TrainerComponent} from './trainer/trainer.component';
import {AdminComponent} from './admin/admin.component';
import {BlockUserComponent} from './block-user/block-user.component';
import {BlockTrainerComponent} from './block-trainer/block-trainer.component';
import { EditTechnologiesComponent } from './edit-technologies/edit-technologies.component';
import { EditSkillsComponent } from './edit-skills/edit-skills.component';
import {SearchComponent} from './search/search.component';
import {UserCompletedTrainingsComponent} from './user-completed-trainings/user-completed-trainings.component';
import {UserCurrentTrainingsComponent} from './user-current-trainings/user-current-trainings.component';
import {TrainerCompletedTrainingsComponent} from './trainer-completed-trainings/trainer-completed-trainings.component';
import {TrainerCurrentTrainingsComponent} from './trainer-current-trainings/trainer-current-trainings.component';
import { NotificationsComponent } from './notifications/notifications.component';

const routes: Routes = [
  { path:'',redirectTo:'/home',pathMatch:'full'},
  { path:'home',component:HomeComponent},
  { path: 'user-login',component:UserLoginComponent},
  { path:'trainer-login', component:TrainerLoginComponent},
  { path:'admin-login', component:AdminLoginComponent},
  { path: 'user-signup',component:UserSignupComponent},
  { path:'trainer-signup', component:TrainerSignupComponent},
  { path: 'user',component:UserComponent},
  { path:'trainer', component:TrainerComponent},
  { path:'admin', component:AdminComponent},
  { path: 'block-user', component:BlockUserComponent},
  {path:'block-trainer',component:BlockTrainerComponent},
  {path:'edit-technologies',component:EditTechnologiesComponent},
  {path:'edit-skills',component:EditSkillsComponent},
  {path:'search',component:SearchComponent},
  {path:'user-completed-trainings',component:UserCompletedTrainingsComponent},
  {path:'user-current-trainings',component:UserCurrentTrainingsComponent},
  {path:'trainer-completed-trainings',component:TrainerCompletedTrainingsComponent},
  {path:'trainer-current-trainings',component:TrainerCurrentTrainingsComponent},
  {path:'notifications', component:NotificationsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
