import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-completed-trainings',
  templateUrl: './user-completed-trainings.component.html',
  styleUrls: ['./user-completed-trainings.component.css']
})
export class UserCompletedTrainingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
